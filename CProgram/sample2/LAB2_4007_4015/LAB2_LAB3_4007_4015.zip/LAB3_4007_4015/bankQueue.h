#ifndef BANKQUEUE_H
#define BANKQUEUE_H

void initialBankQueue();
void customerEnterTheQueue(int customerId);
void callNextCustomerFromQueue(int counterNumber);
void listCustomerInQueue();

#endif //BANKQUEUE_H