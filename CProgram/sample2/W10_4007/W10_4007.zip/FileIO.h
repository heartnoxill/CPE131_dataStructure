#ifndef FILE_IO_H
#define FILE_IO_H

void readFile(char* filename, int* array, int* count);
void writeFile(char* filename, int* array, int count);

#endif // FILE_IO_H
